<?php
include(dirname(__FILE__).'/admin.extplorer.php');