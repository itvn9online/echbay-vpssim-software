#### [alpha]
* 2018.1231.12        / Build 2018-12-31
  ALPHA version

#### [beta]

* 2018.06.01          / Build 2018-06-01
  BETA Version
* 2018.05.31          / Build 2018-05-31
  DEPRECATED Version
* 2018.04.30          / Build 2018-04-30
  DEPRECATED Version
* 2018.03.31          / Build 2018-03-31
  DEPRECATED Version
* 2018.02.28          / Build 2018-02-28
  DEPRECATED Version
* 2018.01.31          / Build 2018-01-31
  DEPRECATED Version
* 2016.1231           / Build 2016-12-31
  DEPRECATED Version
* 2015.1231           / Build 2015-12-31
  DEPRECATED Version

#### [unreleased]
* 2014.1231.2017.11   / Build 2017-11-30
  DEPRECATED Version
* 2014.1231.2017.10   / Build 2017-10-31
  DEPRECATED Version
* 2014.1231.2017.9    / Build 2017-09-30
  DEPRECATED Version
* 2014.1231.2017.8    / Build 2017-08-31
  DEPRECATED Version
* 2014.1231.2017.7    / Build 2017-07-31
  DEPRECATED Version
* 2014.1231.2017.6    / Build 2017-06-30
  DEPRECATED Version  

#### [stable]
* 2014.1231.2017.12   / Build 2017-12-31
  Stable Version
* 2014.1231.2017.5    / Build 2017-11-16
  DEPRECATED Version
* 2014.1231.2017.5    / Build 2017-10-31
  DEPRECATED Version
* 2014.1231.2017.5    / Build 2017-10-30
  DEPRECATED Version
* 2014.1231.2017.5    / Build 2017-10-24
  DEPRECATED Version
* 2014.1231.2017.5    / Build 2017-10-19
  DEPRECATED Version
* 2014.1231.2017.5    / Build 2017-10-05
  DEPRECATED Version
* 2014.1231.2017.5    / Build 2017-09-28
  DEPRECATED Version
* 2014.1231.2017.5    / Build 2017-05-31
  DEPRECATED Version
* 2014.1231.2017.4    / Build 2017-04-30
  DEPRECATED Version
* 2014.1231.2017.3    / Build 2017-03-31
  DEPRECATED Version
* 2014.1231.2017.2    / Build 2017-02-28
  DEPRECATED Version
* 2014.1231.2017.1    / Build 2017-01-31
  DEPRECATED Version

#### [older]
* 2013.1231           / Build 2013-12-31
  LEGACY Version

#### [first]
* 2007.0818.0         / Build 2007-08-18
  DEPRECATED Version

History: 1st 2007-08-18 - latest 2017-12-31

10 Years of WP Missed Schedule development!
