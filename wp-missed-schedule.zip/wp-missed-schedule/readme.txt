=== WP Missed Schedule Original ===
Contributors: sLaNGjIs Team
Requires at least: 2.1
Tested up to: 4.9
Stable tag: 2014.1231.2017.12
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html
Donate link: http://slangjis.org/donate/
Tags: sLaNGjIs, cron job, cron jobs, failed future posts, missed, missed schedule, schedule, scheduled, scheduled missed, scheduled posts,

wordpress plugin wp missed schedule fix scheduled posts failed on virtual cron job bug and republish them fixed 10 items each session every 15 minutes

== Description ==

The Original plugin for WordPress <a href="http://slangjis.org/plugins/wp-missed-schedule/">WP Missed Schedule</a> Fix only scheduled failed future posts, that have this bug, and republish correctly fixed 10 items each session, every 15 minutes, without waste resources. The others will be solved on next sessions, until no longer exist: 10 items every 15 minutes, 40 items every hour, 1 session every 15 minutes, 4 sessions every hour. Work with virtual or real cron job on WordPress from 2.1+ to 4.9+ and 5.0-alpha single or multisite install - The configuration is automatic and plugin nologo! - Build 2017-12-31 - Stable Branche Version 2014.1231.2017.12 - This plugin is no longer available on WordPress.org plugins repository for explicit author request, but only on <a href="https://github.com/sLaNGjI/wp-missed-schedule/">GitHub</a> - [no support provided on WordPress.org forum or reviews](https://slangji.wordpress.com/support/) Please note that on WordPress 4.9+ is recommended (minimum) use of PHP 5.4+ or greater.

**This plugin was approved on this repository online since 2007-08-18**

<strong>The core of the plugin always works even if it is installed in the mu-plugins directory</strong>, but is recommended to not install it in this way, if is not absolutely necessary, because needs to perform the functions of activation, deactivation, installation, uninstallation, to work at 100% of its functionality.

[![Build Status](https://travis-ci.org/sLaNGjI/wp-missed-schedule.svg?branch=master)](https://travis-ci.org/sLaNGjI/wp-missed-schedule/)

<a href="https://slangji.wordpress.com/wp-missed-schedule-pro/">Upgrade to Pro Version</a> | <a href="https://slangji.wordpress.com/wp-missed-schedule-beta/">Beta</a> | <a href="https://slangji.wordpress.com/wp-missed-schedule-gold/">Gold</a> | <a href="http://slangjis.org/support/">Support</a> | <a href="https://github.com/sLaNGjI/wp-missed-schedule">GitHub Project</a> | <a href="https://slangji.github.io/wp-missed-schedule/">GitHub Pages</a> - <a href="http://web.archive.org/web/20140716010606/http://secunia.com/advisories/product/51113/">Secunia</a>

`
275.164+ Downloads 90.000+ Active Installs

A Special Thanks to all who have Installed
`

Missed Schedule is a Bug unfixed since WordPress 2.5+ to date!

> **Premium Support** -- this service is free of charge

> [sLaNGjIs Team not provide support on WordPress.org forum](https://slangji.wordpress.com/support/)

[youtube https://www.youtube.com/watch?v=evlFVjfgb6o]

> **Bug Reports**
>
> Welcomed on [GitHub](https://github.com/sLaNGjI/) but no bugs issues will be closed.

Missed Schedule Fix WP Failed Future Posts

This plugin not decrease server performance why check the internal WordPress virtual cron job, to not waste resources, and not the real cron job of the server at scale.

This plugin check and fix only missed schedule failed future posts scheduled virtual cron job items, and no others, to not waste resources.

This plugin to find and fix all failed future posts stored in the database, using an index table for queries, with the result of obtaining fast queries and a low cpu usage (fast queries and cpu optimization): fully compliant with hyper db table query formatting.

This plugin, in order to reduce the CPU load, and do not use too many resources, repair 10 items in each session, every 15 minutes: the default value of 10 items per session, every 15 minutes, was introduced for compatibility with the default values of WordPress feeds syndication.

This plugin is designed for heavy use of scheduled future posts and rss grabbing, FeedWordPress for example, but also work well with a simple WordPress blog or for use as a cms.

The plugin code was totally rewrited for maximum compatibility with W3 Total Cache and others caching plugins, JetPack and others social publishing plugins, transparency and interference free with others scheduled cron jobs at scale.

This plugin not need others actions from the administrator except activate, deactivate or delete it: is ready to single, network multisite installations, and old WPMU 2.6 to 2.9+ (latest is 2.9.2) multi users and run on shared, dedicated, cloud and vps hosting, with high and low resources.

`
Failed run when a good post goes to future.

When thou go, i shall watch for thee;
When thou absent, i shall reschedule for thee;
When thou think, i shall republish for thee.

Schedule run, but count the cost:
The Posts won, but the Missed is lost!

Proverbs 21:39
`

Read <a href="https://wordpress.org/plugins/wp-missed-schedule/changelog/">Todo List</a> for stay up to date on future changes ...

`
New WP Missed Schedule Features and Future Updates

Active Version 2014.1231.2017.12 (2017-12-31) FREE - STABLE

Limited Missed Scheduled Posts Fixing per days!
Core Optimizations and Transients Improvements
Preemptive Support WordPress 5.0-alpha 2017/18 Release
Preemptive Support WordPress 4.9-RC 2017 Release
Preemptive Support WordPress 4.9-beta 2017 Release
Preemptive Support WordPress 4.9-alpha 2017 Release
Preemptive Support PHP 7.0+ and 7.1+ and 7.2+ or later
Please note that on WP 4.9+ is recommended use of PHP 5.4+
Full Support WordPress Versions 2.1+ to 4.9+
Virtual Cron Checking Interval Method
Secure Key Tag Auth Support (a New Idea of sLa)
Prioritization of Plugin Loading
Full uninstall db Options Clean Support
Check WordPress Version Requirements Before Activation
Self Deactivation Features to match Requirements
Translation Languages Support (basic)
HyperDB Table Query Formatting Compatibility
Fast Queries with index table and CPU Load Optimization
W3 Total Cache and others Caching Plugins Compatibility
JetPack and Social Publishing Plugins Transparency

Beta Version 2018.0131.01 (2018-01-31) BETA - RC

Limited Missed Scheduled Posts Fixing per days!
Real Cron Checking Interval Method
Admin Menu Classic Plugin Settings Page
Admin DashBoard Help and FAQ Panel

Alpha Version 2018.1231.12 (2018-12-31) DEV - ALPHA

Limited Missed Scheduled Posts Fixing per days!
Development Version (code in becoming)
Customization of all Plugin Options (concept only)
All in One Virtual and Real Cron Method (concept only)
Unlimited Missed Scheduled Posts Fixing per days! (pro)
Translation Languages Support (full) (pro)
Check Secure Key Tag Auth Before Activation (pro)
Enable or Disable Frontend Header and Footer Log (pro)
Manual Change the Frequency of Checking (pro)
Manual Change the Number of Failed Posts Fixed (pro)
Switching from Local GMT and UTC Time (pro)
`

= Common Rules =
* Fix Missed Schedule Failed Future Posts Scheduled Items
* Secunia Certified Zero Advisories and Vulnerabilities
* The state of art for fix big core bug since WordPress 2.5+
* Work with all WordPress Versions from 2.1+ to 4.9+
* Preemptive Support for WordPress 5.0-alpha 2017/18 Release
* Preemptive Support for WordPress 4.9-RC
* Preemptive Support for WordPress 4.9-beta
* Preemptive Support for WordPress 4.9-alpha
* Please note that on WP 4.9+ is recommended use of PHP 5.4+
* Compatible with: WordPress, bbPress, Buddypress
* No interference with others Scheduled Cron Jobs at scale
* Ready to Single and Network Multisite Environment
* Full Strict Security Rules Applied
* Repair Failure WordPress Virtual Cron Job Process
* Repair Failure WordPress Real Cron Job Process
* Prioritization of Plugin Loading
* Full uninstall db Options Clean Support
* Check WordPress Version Requirements Before Activation
* Self Deactivation Features to match Requirements
* Translation Languages Support (basic)
* Less Memory Consumption
* Full Support Activation Hook
* Full Support Deactivation Hook
* Full Support Uninstall Hook
* Full Support uninstall.php
* Preemptive Support PHP 7.0+ and 7.1+ and 7.2+ or later
* Support PHP 5.4+ and 5.6+ or later
* Support MySQL 5.5+ and 5.6+ or greater
* Support MariaDB 10.0+ or greater
* Limited Support old PHP 4.0+ and 5.0+ or later
* Limited Support old MySQL 4.0+ and 5.0+ or greater
* Limited Support old MariaDB 5.0+ or greater
* Work with Shared and VPS Hosting
* Work under [GPLv3](https://www.gnu.org/licenses/gpl-3.0.html) or later License
* Implement [GNU style](https://www.gnu.org/prep/standards/standards.html) coding standard indentation
* Meet detailed [Plugin Guidelines](https://wordpress.org/plugins/about/guidelines/) quality requirements
* Support for [Theme Check](https://wordpress.org/plugins/theme-check/) specifications

`
Please noted that on WordPress MultiSite, activation,
and options panel is only available on Super Admin!

Action Link Cron on left when plugin is activated is
accessible only with WP Crontrol plugin Active!
`

Scheduled Posts Regression <a href="https://core.trac.wordpress.org/ticket/22944">#22944</a> fixed on WP 3.5.1 is not related to this plugin.

`
Nothing is written into hosting space disk
wp_option table auto cleaned when deactivate or deleted
No need any others actions except activate or deactivate
No need delete anything from hosting when deactivate
No need delete anything from hosting when deleted
No need delete anything from database when deactivate
No need delete anything from database when deleted
No need delete anything from wp_option when deactivate
No need delete anything from wp_option when deleted
`

* [My others WordPress Plugins](http://slangjis.org/plugins/) on [Softpedia Webscripts](http://webscripts.softpedia.com/publisher/sLa-1869786722.html) [GitHub](https://github.com/sLaNGjI)
 * [WP Overview (lite)](http://slangjis.org/plugins/wp-overview-lite/) (modules updated)
 * [WP Missed Schedule](http://slangjis.org/plugins/wp-missed-schedule/) 275.164+ Downloads 90.000+ Installs
 * [Hide Admin Bar and Toolbar](http://slangjis.org/plugins/global-admin-bar-hide-or-remove/) (new)
 * [WP Admin Bar Removal](http://slangjis.org/plugins/wp-admin-bar-removal/) Linked at [softpedia.com](http://webscripts.softpedia.com/script/Modules/WordPress-Plugins/Admin-Bar-Removal-completely-disable-73547.html)
 * [WP Toolbar Removal](http://slangjis.org/plugins/wp-toolbar-removal/) Linked at [softpedia.com](http://webscripts.softpedia.com/script/Modules/WordPress-Plugins/Toolbar-Removal-completely-disable-73548.html)
 * [IE Enhancer and Modernizer](http://slangjis.org/plugins/wp-ie-enhancer-and-modernizer/) Linked at [softpedia.com](http://webscripts.softpedia.com/script/Modules/WordPress-Plugins/IE-Enhancer-and-Modernizer-73546.html)
 * [Memory Load Consumption db size Usage Indicator](http://slangjis.org/plugins/wp-memory-db-indicator/) (new)
== Installation ==
wp missed schedule special gold edition is for advanced users and was installed only on manual mode
= How to install Special Gold Edition ? =
WARNING: Is not possible to install WP Missed Schedule Gold directly from Admin Control Panel Dasboard.

Clarifications about manual installation of the WP Missed Schedule Special Gold Edition.

Heres everything you need to know:

* Download manually, locally, the gold version from the repository.
* Extract the contents locally.
* Identify the version with a time of checking desired.
* Rename the file locally in wp-missed-schedule.php
* Overwrite, via ftp, the local file with the file that is installed.

Thats it!

There are various versions with the time of checking variable from 1 minute to 36 hours.

For example, you will want to install the version with a time of checking 1 hour, perform the following:

rename wp-missed-schedule-060 to wp-missed-schedule.php

Simple!
= Step by Step Installation =

= For users of single WordPress 2.1+ or later (via FTP) =
1. Download WP Missed Schedule from WordPress.org plugin repository.
1. Upload it into /wp-content/plugins`/wp-missed-schedule/` via FTP.
1. Activate WP Missed Schedule.
= For users of single WordPress 2.7+ or later (manual) =
1. Download WP Missed Schedule from WordPress.org plugin repository.
1. Upload it into your WordPress directly from Plugin Add Feature.
1. It will create a directory /wp-content/plugins`/wp-missed-schedule/`
1. Activate WP Missed Schedule.
= For users of single WordPress 2.7+ or later (auto) =
1. Search WP Missed Schedule from Plugin Add Feature.
1. Install it live directly from WordPress.org repository.
1. It will create a directory /wp-content/plugins`/wp-missed-schedule/`
1. Activate WP Missed Schedule.
= How to uninstall WP Missed Schedule =
1. Disable WP Missed Schedule from Menu Plugins of Control Panel.
1. Delete WP Missed Schedule from Menu Plugins of Control Panel.

[youtube https://www.youtube.com/watch?v=taYO3ZWMwjI]

= What files are officially included on this plgin package? =
Are included 22 files:

1. gitignore
1. htaccess
1. travis.yml
1. CHANGES.md
1. CODE_OF_CONDUCT.md
1. CONTRIBUTING.md
1. LICENSE
1. LICENSE.md
1. changelog.txt
1. checksum.txt
1. gpl-3.0.txt
1. how-to-translate-this-plugin.txt
1. humans.txt
1. important-warning-read-me-asap.txt
1. index.html
1. index.php
1. keybit.txt
1. license.txt
1. no-support-gived-on-forum.txt
1. readme.txt
1. uninstall.php
1. wp-missed-schedule.php

Please verify the authenticity of SHA1 Checksum on your files via [checksum.txt](https://plugins.svn.wordpress.org/wp-missed-schedule/trunk/checksum.txt)
= Troubleshooting =
If all else fails and your site is broken remove directly via ftp on your host space /home/your-wp-install-dir/wp-content/plugins`/wp-missed-schedule/`.
= Action Link Cron =
Please Noted That: Action Link Cron on left when plugin is activated is accessible only with [WP Crontrol](https://wordpress.org/plugins/wp-crontrol/) Active (error: You do not have sufficient permissions to access this page.)
= WordPress Multisite =
Remenber That: if WordPress MultiSite is active WP Missed Schedule activation, and options panel, is only available on Super Admin Menu.
== Frequently Asked Questions ==
reasons why WordPress virtual cron job fails could be due to:

* wp-cron not executed on heavy servers load
* wp-cron rarely executed on unvisited servers
* Plugins and Themes conflict
* WordPress bugs: Missed Schedule is a WordPress Bug!
* DNS issue in the server
* DNS issue in the database
* Server Timezone Misconfiguration
* Database Timezone Misconfiguration
* Using cache plugins that prevent WP-Cron from loading
* Using cache objects that prevent WP-Cron from loading
* And many others reasons

= Who Translate This Plugin? =

= How can i get involved? =
GlotPress translations was not supported from this plugin because:

* Translation link exposes the plugins to pushing malicious url?
* Translation description exposes the plugin to change its original meaning?
* Editors may approve or disapprove according personal rules or motivations?
* Not all GlotPress Editors respect plugin Authors directions?
* The approval process is too long?
* Changing the content of the plugin, makes useless all the previous approval process, returning a translation, which no longer conforms to the original content, with the resulting of forcing the author to limiting what is really important to add in his descriptions and link, on future and actual changes.

= How to translate it? =
Is possible to make translations, with traditional method,
using wp-missed-schedule.pot not included on plugin package,
and available on [assets](https://plugins.svn.wordpress.org/wp-missed-schedule/assets/languages/) to reduce the size of
ZIP file being served, and no waste user space/bandwidth.

After, send it to sLaNGjIs Team for approval, and publishing.
Translator Credits was applied, indicated, with the name
of your editor, on readme.txt of this plugin, and also
on related [translations page](http://slangji.wordpress.com/translations/)
= Free plugin version support translations? =
No, free plugin support basic translations: only Pro Version support full translations.
= WPML is supported? =
Sorry, is not supported, in any version, for now.
= The WordPress Missed Scheduled Failed Future Posts Who? =
WordPress comes with its own cron job that allows you to schedule your posts and events, however, in many situations, the wp-cron is not working well and leads to posts missed their publication schedule and/or scheduled events not executed.

To understand why this happen, we need to know that the WP-Cron is not a real cron job. It is in fact a virtual cron that only works when a page is loaded. In short, when a page is requested on the frontend/backend, WordPress will first load WP-Cron, follow by the necessary page to display to your reader. The loaded WP-Cron will then check the database to see if there is any thing that needs to be done.

Publish a bunch of future posts noticed that they wont publish and when time comes to go live they just turn Missed Schedule. Took a look at the Wordpress code and noticed future posts get assigned a cronjob `($unix_time_stamp, publish_future_post, array($post_ID))` [wp_schedule_single_event](https://codex.wordpress.org/Function_Reference/wp_schedule_single_event) Why dont you just look at the database and publish all posts with future status and date in past? My plugin WP Missed Shcedule looks for posts with a date in the past that still have `post_status=future`. It will take each `post_ID` and publish [wp_publish_post](https://codex.wordpress.org/Function_Reference/wp_publish_post) it.
= How to Work? =
This plugin will check every 15 minutes, if there are posts that match the problem described. [WPMS_DELAY 15] To not use too many resources, it fix for 10 items per session [LIMIT 10] one session every 15 minutes. All others failed will be solved in future sessions, until no longer exist. When you activate this plugin, the first 10 Missed Scheduled Future Posts are fixed immediately. All others are fixed the next batch. On some case (rare?) are also fixed live. If you have Missed Scheduled Future Posts after this plugin is activated, is not one error or bug: wait the next checking. If Missed Scheduled Future Posts persist, verify that WordPress installation is clean, or exist conflict with others plugins.

N.B. If have active others plugins with the same functions of WP Missed Schedule this is on conflict and not work. I suggest to delete or deactivate all others, clean related database options table, and use only WP Missed Schedule. In the same way WP Missed Schedule could create conflicts with others plugins with the same functions. In this case, delete or disable it and only used the others.
= Dealing with WordPress Missed Schedule =
If you are scheduling blog posts in WordPress and seeing a Missed Schedule message, its likely caused by an issue with your web server, or it is WordPress that is causing the problem of your blog posts not being posted as scheduled. This is an annoying problem. However, there is a very simple fix that is easy to do. The Missed Schedule problem seems to point to the web server and WordPress. The time/date comparison needs to match in order for your blog posts to get published as scheduled. If you are currently using the WordPress, blogging platform, you can easily fix the issue by modifying the wp-cron.php file which is located in the root folder. You simply open your notepad editor in Windows and search for the following line of code, which is located towards the bottom on the file wp-cron.php file.

This is the code you need to search for: `update_option(doing_cron, 0);`

This is the code you need to replace it with: `//update_option(doing_cron, 0);`

Next step is to save the wp-cron.php file and upload to your web server. However, make sure that you renamed the current wp-cron.php on the web server to wp-cron.php-org, just in case there is an issue, and you need to resort back to the original file. The final step is to schedule another blog post and make sure that it processes correctly and that it gets published according to schedule. To manually run the cron, youll need to type or paste the code below in your browser URL without the brackets yourdomain.com/wp-cron.php. If things are working correctly, it should return a blank screen. Furthermore, this should update the time/date comparison between your web server and WordPress.
= The Missed Schedule Problem =
The way WordPress handles scheduling is that whenever a page is loaded, either from your blog or in your admin control panel, the file wp-cron.php is loaded. At normal, if correctly configured, the server can talk to itself just fine and WordPress scheduling system will works perfectly. Its only when you start doing strange and weird things like not having DNS setup properly or blocking loopback connections then it will cause you problems. It is possible that certain web hosts are not allowing WordPress cron jobs to run but for many that is not the issue as scheduled posting was working before upgrading to WordPress 2.7.

In WordPress 2.7, the cron job design, which is the core of the scheduling engine, is significantly changed as you can from both wp-cron.php and cron.php in /wp-includes/ folder. In WordPress 2.7 wp-cron.php, there are references to local-time and doing_cron option is set to zero. This is not exist in WordPress version 2.6.5. This might be the cause of the problem as its very likely that your web server time is off by a few seconds or minutes from the WordPress official time. And doing_cron argument is set to zero making it absolutely necessary that your web server and WordPress time to match with each others in order for the scheduled post to go through.
= Solutioni #1 =
If you think that your web server settings is the cause of the problem, simply type this URL in your browser without the brackets yourblog.com/wp-cron.php (replace yourblog with your actual domain name) to verify. If you see a blank screen, then your web server settings is ok. You can proceed to solution #2. If you see some error pages, then kindly check with your web hosting technical staff and ask for their help.
= Solution #2 =
This is the solution to fix local-time and doing_cron option in wp-cron.php. If your programming is good enough, you are free to change the code and fix the issue yourselves. Remember to backup your WordPress before applying any change in production.

If youre not familiar with programming, dont worry, there is a simple solution.

1. Download WordPress version 2.6.5 from WordPress repository
1. Extract both wp-cron.php and cron.php file from version 2.6.5
1. Backup your WordPress database
1. Rename both wp-cron.php and cron.php in your web server to another name
1. Upload both wp-cron.php and cron.php extracted from version 2.6.5 to your server
= Conclusion = 
I hope the fix working fine for you. WordPress should really look into this issue seriously and provide a fix or help to resolve the issue faced by many of the bloggers. If WordPress is not able to publish future post at predefined time, it should recheck it periodically for several time, says every 10/15 minutes, and publish the post as soon as possible.
== Screenshots ==
1. Missed schedule - English Language Screenshot
2. Programación perdida - Spanish Language Screenshot
3. Planification manquée - French Language Screenshot
4. Verpasste Planung - German Language Screenshot
5. Programmazione saltata - Italian Language Screenshot
6. Programmazione mancante - Italian Language Screenshot
7. Публикация просрочена - Russian Language Screenshot
8. Language Screenshot
9. Language Screenshot
10. Language Screenshot
11. Language Screenshot
12. Language Screenshot
== Changelog ==
available [new beta version](https://slangji.wordpress.com/wp-missed-schedule-beta/) with code totally rewrited that applies innovative method for interval of checking with lowest load server. This plugin patched an important unfixed issue since WordPress 2.5+ to date because Missed Schedule is Bug! All previous versions, before latest stable, are deprecated, no longer supported, and your distribution files silenty updated: please re-download or re-install it, based on build date, rather on version! This plugin is no longer available on WordPress.org plugins repository for explicit author request, but only on [GitHub](https://github.com/sLaNGjI/wp-missed-schedule/) - Build 2017-12-31 - Stable Branche Version 2014.1231.2017.12 - [no support provided on WordPress.org forum or reviews](https://slangji.wordpress.com/support/) Please note that on WordPress 4.9+ is recommended (minimum) use of PHP 5.4+ or greater.

**This plugin was approved on this repository online since 2007-08-18**

<strong>The core of the plugin always works even if it is installed in the mu-plugins directory</strong>, but is recommended to not install it in this way, if is not absolutely necessary, because needs to perform the functions of activation, deactivation, installation, uninstallation, to work at 100% of its functionality.

<a href="https://slangji.wordpress.com/wp-missed-schedule-pro/">Upgrade to Pro Version</a> | <a href="https://slangji.wordpress.com/wp-missed-schedule-beta/">Beta</a> | <a href="https://slangji.wordpress.com/wp-missed-schedule-gold/">Gold</a> | <a href="http://slangjis.org/support/">Support</a> | <a href="https://github.com/sLaNGjI/">GitHub</a> | <a href="http://web.archive.org/web/20140716010606/http://secunia.com/advisories/product/51113/">Secunia</a>

`
275.164+ Downloads 90.000+ Active Installs

A Special Thanks to all who have Installed
`

We always recommend upgrading to the latest version!

`
Legend:

Branche is identified with year on top to first
version number (*2014*.1231.0) 2014 for example.

Build is identified with progressive number on
middle version number (2014.*1231*.0) 2014-12-31.

Revision is identified with progressive number on
last version number (2014.1231.*1*) 1 for example.

Update is identified with progressive number after
last version number (2014.1231.1.*2*) 2 for example.
`

* 275.298+ Downloads 60.000+ Active Installs Day 2017-11-30
* 275.164+ Downloads 90.000+ Active Installs Day 2016-04-13
* 270.000+ Downloads 90.000+ Active Installs Day 2016-03-28
* 260.000+ Downloads 80.000+ Active Installs Day 2016-01-25
* 250.000+ Downloads 70.000+ Active Installs Day 2015-12-31
* 200.000+ Downloads 60.000+ Active Installs Day 2015-08-25

= 2014.1231.2017.12 =
* Major [RELEASE] The best WP Missed Schedule of ever!
 * Please update as soon as possible!
 * Undeveloped on wordpress.org since 2016-04-13
 * Available on GitHub only for Author Request!
 * Branche 2014 Build 2017-12-31 Revision 2017-12-31 Update 12
 * Release 2014 Version 1231 Revision 2017 Update 12
 * Work with all WordPress Versions from 2.1+ to 4.9+
 * Full Support and Compatibility for WordPress 2.1+ - 4.9+
 * Preemptive Support for WordPress 5.0-alpha
 * Please note that on WP 4.9+ is recommended use of PHP 5.4+ or 5.6+
 * Preemptive Support PHP 7.0+ and 7.1+ and 7.2+ or later
 * NEW Code cleaning and optimized
 * ENHANCEMENT Fixed minor issues with WordPress 2.1 to 2.9+
 * MAINTENANCE Release According WordPress 4.9.2
 * MAINTENANCE Release According WordPress 4.8.5
 * MAINTENANCE Release According WordPress 4.7.9
 * MAINTENANCE Release According WordPress 4.6.10
 * MAINTENANCE Release According WordPress 4.5.13
 * MAINTENANCE Release According WordPress 4.4.14
 * MAINTENANCE Release According WordPress 4.3.15
 * MAINTENANCE Release According WordPress 4.2.19
 * MAINTENANCE Release According WordPress 4.1.22
 * MAINTENANCE Release According WordPress 4.0.22
 * MAINTENANCE Release According WordPress 3.9.23
 * MAINTENANCE Release According WordPress 3.8.25
 * MAINTENANCE Release According WordPress 3.7.25

= 2014.1231.2017.5 =
* Reloaded [UPDATE] Improvements and Maintenance Release
 * Please update as soon as possible!
 * Undeveloped on wordpress.org since 2016-04-13
 * Available on GitHub only for Author Request!
 * Branche 2014 Build 2017-05-31 Revision 2017-11-16
 * Branche 2014 Build 2017-05-31 Reloaded 2017-10-30
 * Release 2014 Version 1231 Revision 2017 Update 5
 * Work with all WordPress Versions from 2.1+ to 4.9+
 * Full Support and Compatibility for WordPress 2.1+ - 4.9+
 * Preemptive Support for WordPress 5.0-alpha
 * Preemptive Support for WordPress 4.9-RC
 * Preemptive Support for WordPress 4.9-beta
 * Preemptive Support for WordPress 4.9-alpha
 * Please note that on WP 4.9+ is recommended use of PHP 5.4+
 * Preemptive Support PHP 7.0+ and 7.1+ and 7.2+ or later
 * NEW Authenticity Checking
 * UPDATED Security Checking
 * ENHANCEMENT Core and Transients Improvements
 * FIXED False Positive Malware Warning when Updating
 * MAINTENANCE Release According WordPress 4.9.1
 * MAINTENANCE Release According WordPress 4.9
 * MAINTENANCE Release According WordPress 4.8.4
 * MAINTENANCE Release According WordPress 4.8.3
 * MAINTENANCE Release According WordPress 4.8.2
 * MAINTENANCE Release According WordPress 4.8.1
 * MAINTENANCE Release According WordPress 4.8
 * MAINTENANCE Release According WordPress 4.7.8
 * MAINTENANCE Release According WordPress 4.7.7
 * MAINTENANCE Release According WordPress 4.7.6
 * MAINTENANCE Release According WordPress 4.6.9
 * MAINTENANCE Release According WordPress 4.6.8
 * MAINTENANCE Release According WordPress 4.6.7
 * MAINTENANCE Release According WordPress 4.5.12
 * MAINTENANCE Release According WordPress 4.5.11
 * MAINTENANCE Release According WordPress 4.5.10
 * MAINTENANCE Release According WordPress 4.4.13
 * MAINTENANCE Release According WordPress 4.4.12
 * MAINTENANCE Release According WordPress 4.4.11
 * MAINTENANCE Release According WordPress 4.3.14
 * MAINTENANCE Release According WordPress 4.3.13
 * MAINTENANCE Release According WordPress 4.3.12
 * MAINTENANCE Release According WordPress 4.2.18
 * MAINTENANCE Release According WordPress 4.2.17
 * MAINTENANCE Release According WordPress 4.2.16
 * MAINTENANCE Release According WordPress 4.1.21
 * MAINTENANCE Release According WordPress 4.1.20
 * MAINTENANCE Release According WordPress 4.1.19
 * MAINTENANCE Release According WordPress 4.0.21
 * MAINTENANCE Release According WordPress 4.0.20
 * MAINTENANCE Release According WordPress 4.0.19
 * MAINTENANCE Release According WordPress 3.9.22
 * MAINTENANCE Release According WordPress 3.9.21
 * MAINTENANCE Release According WordPress 3.9.20
 * MAINTENANCE Release According WordPress 3.8.24
 * MAINTENANCE Release According WordPress 3.8.23
 * MAINTENANCE Release According WordPress 3.8.22
 * MAINTENANCE Release According WordPress 3.7.24
 * MAINTENANCE Release According WordPress 3.7.23
 * MAINTENANCE Release According WordPress 3.7.22

= 2014.1231.2017.4 =
* Security [UPDATE] Security and Maintenance Release
 * Please update as soon as possible!
 * Undeveloped on wordpress.org since 2016-04-13
 * Available on GitHub only for Author Request!
 * Branche 2014 Build 2017-05-21
 * Release 2014 Version 1231 Revision 2017 Update 4
 * Work with all WordPress Versions from 2.1+ to 4.7+
 * Full Support and Compatibility for WordPress 2.1+ - 4.7+
 * Preemptive Support for WordPress 4.8-beta
 * MAINTENANCE Release According WordPress 4.7.5
 * MAINTENANCE Release According WordPress 4.6.6
 * MAINTENANCE Release According WordPress 4.5.9
 * MAINTENANCE Release According WordPress 4.4.10
 * MAINTENANCE Release According WordPress 4.3.11
 * MAINTENANCE Release According WordPress 4.2.15
 * MAINTENANCE Release According WordPress 4.1.18
 * MAINTENANCE Release According WordPress 4.0.18
 * MAINTENANCE Release According WordPress 3.9.19
 * MAINTENANCE Release According WordPress 3.8.21
 * MAINTENANCE Release According WordPress 3.7.21
= 2014.1231.2017.3 =
* Compatibility [UPDATE] Maintenance Release
 * Please update as soon as possible!
 * Undeveloped on wordpress.org since 2016-04-13
 * Available on GitHub only for Author Request!
 * Branche 2014 Build 2017-04-20
 * Release 2014 Version 1231 Revision 2017 Update 3
 * Work with all WordPress Versions from 2.1+ to 4.7+
 * Full Support and Compatibility for WordPress 2.1+ - 4.7+
 * Preemptive Support for WordPress 4.8-alpha
 * MAINTENANCE Release According WordPress 4.7.4
 * MAINTENANCE Release According WordPress 4.6.5
 * MAINTENANCE Release According WordPress 4.5.8
 * MAINTENANCE Release According WordPress 4.4.9
 * MAINTENANCE Release According WordPress 4.3.10
 * MAINTENANCE Release According WordPress 4.2.14
 * MAINTENANCE Release According WordPress 4.1.17
 * MAINTENANCE Release According WordPress 4.0.17
 * MAINTENANCE Release According WordPress 3.9.18
 * MAINTENANCE Release According WordPress 3.8.20
 * MAINTENANCE Release According WordPress 3.7.20
= 2014.1231.2017.2 =
* Compatibility [UPDATE] Maintenance Release
 * Please update as soon as possible!
 * Undeveloped on wordpress.org since 2016-04-13
 * Available on GitHub only for Author Request!
 * Branche 2014 Build 2017-03-16
 * Release 2014 Version 1231 Revision 2017 Update 2
 * Work with all WordPress Versions from 2.1+ to 4.7+
 * Full Support and Compatibility for WordPress 2.1+ - 4.7+
 * Preemptive Support for WordPress 4.8-alpha
 * MAINTENANCE Release According WordPress 4.7.3
 * MAINTENANCE Release According WordPress 4.6.4
 * MAINTENANCE Release According WordPress 4.5.7
 * MAINTENANCE Release According WordPress 4.4.8
 * MAINTENANCE Release According WordPress 4.3.9
 * MAINTENANCE Release According WordPress 4.2.13
 * MAINTENANCE Release According WordPress 4.1.16
 * MAINTENANCE Release According WordPress 4.0.16
 * MAINTENANCE Release According WordPress 3.9.17
 * MAINTENANCE Release According WordPress 3.8.19
 * MAINTENANCE Release According WordPress 3.7.19
= 2014.1231.2017.1 =
* Support [UPDATE] Important and Improved Major Update
 * Please update as soon as possible!
 * Undeveloped on wordpress.org since 2016-04-13
 * Available on GitHub only for Author Request!
 * Branche 2014 Build 2017-01-26
 * Release 2014 Version 1231 Revision 2017 Update 1
 * Work with all WordPress Versions from 2.1+ to 4.7+
 * Full Support and Compatibility for WordPress 2.1+ - 4.7+
 * Preemptive Support for WordPress 4.8-alpha
 * ADD gpl-3.0.txt
 * DELETED gpl-2.0.txt
 * ENHANCEMENT Somes Core Improvements
 * ENHANCEMENT Somes Transients Improvements
 * FIXED checksun.txt and SHA1 values
 * MIGRATED Licensing from GPLv2 to GPLv3
 * UPDATED LICENSE.md
 * UPDATED license.txt
 * UPDATED Plugin Activation Procedure
 * UPDATED Plugin Deactivation Procedure
 * UPDATED Plugin Uninstall Routines
 * UPDATED Plugin HTTP send Headers
 * UPDATED Security Rules
 * UPDATED index.html
 * UPDATED index.php
 * UPDATED .travis.yml
 * MAINTENANCE Release According WordPress 4.7.2
 * MAINTENANCE Release According WordPress 4.7.1
 * MAINTENANCE Release According WordPress 4.6.3
 * MAINTENANCE Release According WordPress 4.6.2
 * MAINTENANCE Release According WordPress 4.5.6
 * MAINTENANCE Release According WordPress 4.5.5
 * MAINTENANCE Release According WordPress 4.4.7
 * MAINTENANCE Release According WordPress 4.4.6
 * MAINTENANCE Release According WordPress 4.3.8
 * MAINTENANCE Release According WordPress 4.3.7
 * MAINTENANCE Release According WordPress 4.2.12
 * MAINTENANCE Release According WordPress 4.2.11
 * MAINTENANCE Release According WordPress 4.1.15
 * MAINTENANCE Release According WordPress 4.1.14
 * MAINTENANCE Release According WordPress 4.0.15
 * MAINTENANCE Release According WordPress 4.0.14
 * MAINTENANCE Release According WordPress 3.9.16
 * MAINTENANCE Release According WordPress 3.9.15
 * MAINTENANCE Release According WordPress 3.8.18
 * MAINTENANCE Release According WordPress 3.8.17
 * MAINTENANCE Release According WordPress 3.7.18
 * MAINTENANCE Release According WordPress 3.7.17
= 2014.1231.2016.7 =
* Support [UPDATE] Preemptive Support WordPress 4.8-alpha
 * Please update as soon as possible!
 * Undeveloped on wordpress.org since 2016-04-13
 * Available on GitHub only for Author Request!
 * Branche 2014 Build 2016-12-08
 * Release 2014 Version 1231 Revision 2016 Update 7
 * Work with all WordPress Versions from 2.1+ to 4.7+
 * Full Support and Compatibility for WordPress 2.1+ - 4.7+
 * Preemptive Support for WordPress 4.8-alpha
 * MAINTENANCE Release According WordPress 4.7
 * MAINTENANCE Release According WordPress 4.6.1
 * MAINTENANCE Release According WordPress 4.5.4
 * MAINTENANCE Release According WordPress 4.4.5
 * MAINTENANCE Release According WordPress 4.3.6
 * MAINTENANCE Release According WordPress 4.2.10
 * MAINTENANCE Release According WordPress 4.1.13
 * MAINTENANCE Release According WordPress 4.0.13
 * MAINTENANCE Release According WordPress 3.9.14
 * MAINTENANCE Release According WordPress 3.8.16
 * MAINTENANCE Release According WordPress 3.7.16
= 2014.1231.2016.6 =
* Support [UPDATE] Preemptive Support WordPress 4.8-alpha
 * Please update as soon as possible!
 * Undeveloped on wordpress.org since 2016-04-13
 * Available on GitHub only for Author Request!
 * Branche 2014 Build 2016-12-06
 * Release 2014 Version 1231 Revision 2016 Update 6
 * Work with all WordPress Versions from 2.1+ to 4.7+
 * Full Support and Compatibility for WordPress 2.1+ - 4.7+
 * Preemptive Support for WordPress 4.8-alpha
 * MAINTENANCE Release According WordPress 4.7
 * MAINTENANCE Release According WordPress 4.6.1
 * MAINTENANCE Release According WordPress 4.5.4
 * MAINTENANCE Release According WordPress 4.4.5
 * MAINTENANCE Release According WordPress 4.3.6
 * MAINTENANCE Release According WordPress 4.2.10
 * MAINTENANCE Release According WordPress 4.1.13
 * MAINTENANCE Release According WordPress 4.0.13
 * MAINTENANCE Release According WordPress 3.9.14
 * MAINTENANCE Release According WordPress 3.8.16
 * MAINTENANCE Release According WordPress 3.7.16
= 2014.1231.2016.5 =
* Support [UPDATE] Preemptive Support WordPress 4.7-beta
 * Please update as soon as possible!
 * Undeveloped on wordpress.org since 2016-04-13
 * Available on GitHub only for Author Request!
 * Branche 2014 Build 2016-10-28
 * Release 2014 Version 1231 Revision 2016 Update 5
 * Work with all WordPress Versions from 2.1+ to 4.6+
 * Full Support and Compatibility for WordPress 2.1+ - 4.6+
 * Preemptive Support for WordPress 4.7-beta
 * Preemptive Support for WordPress 4.7-alpha
 * MAINTENANCE Release According WordPress 4.6.1
 * MAINTENANCE Release According WordPress 4.5.4
 * MAINTENANCE Release According WordPress 4.4.5
 * MAINTENANCE Release According WordPress 4.3.6
 * MAINTENANCE Release According WordPress 4.2.10
 * MAINTENANCE Release According WordPress 4.1.13
 * MAINTENANCE Release According WordPress 4.0.13
 * MAINTENANCE Release According WordPress 3.9.14
 * MAINTENANCE Release According WordPress 3.8.16
 * MAINTENANCE Release According WordPress 3.7.16
= 2014.1231.2016.4 =
* Support [UPDATE] Preemptive Support WordPress 4.7-alpha
 * Please update as soon as possible!
 * Undeveloped on wordpress.org since 2016-04-13
 * Available on GitHub only for Author Request!
 * Branche 2014 Build 2016-09-16
 * Release 2014 Version 1231 Revision 2016 Update 4
 * Work with all WordPress Versions from 2.1+ to 4.6+
 * Full Support and Compatibility for WordPress 2.1+ - 4.6+
 * Preemptive Support for WordPress 4.7-alpha
 * MAINTENANCE Release According WordPress 4.6.1
 * MAINTENANCE Release According WordPress 4.5.4
 * MAINTENANCE Release According WordPress 4.4.5
 * MAINTENANCE Release According WordPress 4.3.6
 * MAINTENANCE Release According WordPress 4.2.10
 * MAINTENANCE Release According WordPress 4.1.13
 * MAINTENANCE Release According WordPress 4.0.13
 * MAINTENANCE Release According WordPress 3.9.14
 * MAINTENANCE Release According WordPress 3.8.16
 * MAINTENANCE Release According WordPress 3.7.16
= 2014.1231.2016.3 =
* Maintenance [UPDATE] Compatibility and Reliability Update!
 * Please update as soon as possible!
 * Undeveloped on wordpress.org since 2016-04-13
 * Available on GitHub only for Author Request!
 * Branche 2014 Build 2016-08-14
 * Release 2014 Version 1231 Revision 2016 Update 3
 * Work with all WordPress Versions from 2.1+ to 4.6+
 * Full Support and Compatibility for WordPress 2.1+ - 4.6+
 * Preemptive Support for WordPress 4.7-alpha
 * MAINTENANCE Release According WordPress 4.6
 * MAINTENANCE Release According WordPress 4.5.3
 * MAINTENANCE Release According WordPress 4.5.2
 * MAINTENANCE Release According WordPress 4.4.4
 * MAINTENANCE Release According WordPress 4.3.5
 * MAINTENANCE Release According WordPress 4.2.9
 * MAINTENANCE Release According WordPress 4.1.12
 * MAINTENANCE Release According WordPress 4.0.12
 * MAINTENANCE Release According WordPress 3.9.13
 * MAINTENANCE Release According WordPress 3.8.15
 * MAINTENANCE Release According WordPress 3.7.15
= 2014.1231.2016.2 =
* Freedom [UPDATE] Undeveloped on wordpress.org since 2016-04-13
 * Please update as soon as possible!
 * Branche 2014 Build 2016-04-13
 * Release 2014 Version 1231 Revision 2016 Update 2
 * Work with all WordPress Versions from 2.1+ to 4.5.0+
 * Full Support and Compatibility for WordPress 2.1+ - 4.5.0+
 * Preemptive Support for WordPress 4.6-beta
 * MAINTENANCE Release According WordPress 4.5.1
 * MAINTENANCE Release According WordPress 4.4.3
 * MAINTENANCE Release According WordPress 4.3.4
 * MAINTENANCE Release According WordPress 4.2.8
 * MAINTENANCE Release According WordPress 4.1.11
 * MAINTENANCE Release According WordPress 4.0.11
 * MAINTENANCE Release According WordPress 3.9.13
 * MAINTENANCE Release According WordPress 3.8.14
 * MAINTENANCE Release According WordPress 3.7.14
= 2014.1231.2016.1 =
* Multisite Improvements [UPDATED] Speed and Maintenance!
 * Please update as soon as possible!
 * Branche 2014 Build 2016-04-11
 * Release 2014 Version 1231 Revision 2016 Update 1
 * Work with all WordPress Versions from 2.1+ to 4.5.0+
 * Full Support and Compatibility for WordPress 2.1+ - 4.5.0+
 * Preemptive Support for WordPress 4.6-alpha
 * FIXED Somes Multisite Issues
 * UPDATED Somes Minor Bugs
 * ENHANCEMENT Multisite Improvements
 * ENHANCEMENT Speed and Reliability
 * MAINTENANCE Release According WordPress 4.5
 * MAINTENANCE Release According WordPress 4.4.2
 * MAINTENANCE Release According WordPress 4.3.3
 * MAINTENANCE Release According WordPress 4.2.7
 * MAINTENANCE Release According WordPress 4.1.10
 * MAINTENANCE Release According WordPress 4.0.10
 * MAINTENANCE Release According WordPress 3.9.11
 * MAINTENANCE Release According WordPress 3.8.13
 * MAINTENANCE Release According WordPress 3.7.13
= 2014.1231.2016.0 =
* Security Release [UPDATED] Security and Maintenance!
 * Please update as soon as possible!
 * Branche 2014 Build 2016-01-06
 * Release 2014 Version 1231 Revision 2016 Update 0
 * Full Support and Compatibility for WordPress 2.1+ - 4.4.0+
 * Preemptive Support for WordPress 4.5-beta
 * SECURITY Secunia Zero Advisories and Vulnerabilities
 * SECURITY a new idea of sLa: KeyTag and AuthTag authenticity
 * SECURITY keybit.txt plugin authenticity protection
 * SECURITY checksum.txt sha1 checksum files declaration
 * SECURITY index.html directory listing protection
 * SECURITY index.php directory listing protection
 * SECURITY prevent direct access to php files on this plugin
 * MAINTENANCE Release According WordPress 4.4.1
 * MAINTENANCE Release According WordPress 4.3.2
 * MAINTENANCE Release According WordPress 4.2.6
 * MAINTENANCE Release According WordPress 4.1.9
 * MAINTENANCE Release According WordPress 4.0.9
 * MAINTENANCE Release According WordPress 3.9.10
 * MAINTENANCE Release According WordPress 3.8.12
 * MAINTENANCE Release According WordPress 3.7.12
 * NEW Work with all WordPress Versions from 2.1+ to 4.4.0+
 * NEW Strict Transients Support
 * UPDATED uninstall.php
 * UPDATED readme.txt
 * UPDATED Screenshot Languages Samples
 * INCLUDED All Features of Major Release 2014.1231.2015
= 2014.1231.2015.4 =
* Major Release [UPDATED] Self Deactivation Features!
 * Please update as soon as possible!
 * Branche 2014 Build 2015-12-31
 * Release 2014 Version 1231 Revision 2015 Update 4
 * Full Support and Compatibility for WordPress 2.1+ - 4.4.0+
 * Preemptive Support for WordPress 4.5-alpha
 * MAINTENANCE Release According WordPress 4.4
 * MAINTENANCE Release According WordPress 4.3.1
 * MAINTENANCE Release According WordPress 4.3
 * MAINTENANCE Release According WordPress 4.2.5
 * MAINTENANCE Release According WordPress 4.2.4
 * MAINTENANCE Release According WordPress 4.2.3
 * MAINTENANCE Release According WordPress 4.2.2
 * MAINTENANCE Release According WordPress 4.2.1
 * MAINTENANCE Release According WordPress 4.2
 * FIXED Control Panel Loop and Dashboard Freeze
 * FIXED If Requirements Not Match Control Panel Loop
 * FIXED If Requirements Not Match Dashboard Freeze
 * FIXED Somes Priority Filter Issues
 * NEW Work with all WordPress Versions from 2.1+ to 4.4.0+
 * NEW Transients Caching to Reduce db Queries and Server Load
 * NEW Prioritization of Plugin Loading
 * NEW Plugin Self Deactivation if Requirements Not Match
 * NEW If Requirements Not Match Plugin is Not Loaded
 * NEW Full db wp_options cleanup on activation (anticorrupted)
 * NEW Full db wp_options cleanup on uninstall or deactivation
 * ADD Multisite Uninstall Routine Compatibility Support
 * UPDATED Pre-Activation-Deactivation-Uninstall Code
 * UPDATED Somes Priority Filters Values
 * INCLUDED All Features of Major Release 2014.1231.2014
 *
 * PREVIOUS 2014.1231.2014 RELEASE HISTORY
 *
 * Major Release [UPDATED] Bugs Fixing Forcing!
 * Branche 2014 Build 2014-12-31
 * Release 2014 Version 1231 Revision 2014 Update 0
 * Full Support and Compatibility for WordPress 2.1+ - 4.1+
 * Preemptive Support for WordPress 4.2-alpha
 * MAINTENANCE Release According WordPress 4.1+
 * MAINTENANCE Release According WordPress 4.0+
 * MAINTENANCE Release According WordPress 3.9+
 * FIXED ticket #7121343 [Annoying PHP Debug Notices](https://wordpress.org/support/topic/php-notice-53)
 * FIXED ticket #6739625 [SQL EOL CRLF (dos) Mode Problems](https://wordpress.org/support/topic/help-with-activating-on-multisite)
 * FIXED ticket #6642239 [Undefined Constant Warning](https://wordpress.org/support/topic/undefined-constant-warning)
 * FIXED ticket #6432784 [This Plugin Not Have Valid Header](https://wordpress.org/support/topic/the-plugin-does-not-have-a-valid-header-72)
 * FIXED ticket #6206852 [Published all Missed Posts at Once](https://wordpress.org/support/topic/published-all-missed-sheduled-posts-at-once-after-installing)
 * FIXED ticket #5982900 [Others Scheduling Updates Isolation](https://wordpress.org/support/topic/could-this-plugin-break-other-schedule-update-plugins)
 * FIXED ticket #5338146 [wpms_init run on every page load](https://wordpress.org/support/topic/wpms_init-runs-on-every-page-load)
 * FIXED ticket #5333092 [Plugin Caching Improvement](https://wordpress.org/support/topic/possible-plugin-improvement)
 * FIXED ticket #5241196 [Server Queries Timeout](https://wordpress.org/support/topic/query-timeouts-with-plugin-active)
 * FIXED ticket #4643184 [Reduced Info Header](https://wordpress.org/support/topic/how-to-remove-plugin-info-in-header)
 * FIXED ticket #4570622 [db post_date_gmt not indexed](https://wordpress.org/support/topic/plugin-uses-post_date_gmt-which-is-not-indexed)
 * FIXED db post_date_utc Support on WordPress 2.3+ or later
 * NEW Work with all WordPress Versions from 2.1+ to 4.1+
 * NEW Transients Caching to Reduce db Queries and Server Load
 * NEW Prioritization of Plugin Loading
 * NEW Full Support uninstall.php
 * NEW Full Support Uninstall Hook
 * MIGRATED Plugin EOL CRLF (dos) to LF (unix) code
 * CONVERTED EOL SQL CRLF (dos) to LF (unix) code
 * IMPORTED Key and Auth Tag from Pro Version
 * UPDATED Header and Footer Log Code
 * ADDED security rules to activate and manage functions
 * REVISED some possible paranoid security issues
 * DISABLED identification of version and build installed
 * MIGRATED MD5 Checksum to SHA1
 * SECURITY only admins view backend header and footer log
 * SECURITY limited frontend header and footer log to home
 * UPDATED realtime checking: 1 session every 15 minutes
 * UPDATED realtime checking: 4 sessions every hour
 * UPDATED realtime checking: 10 future posts every 15 minutes
 * UPDATED realtime checking: 40 items every hour
 * UPDATED Support and Compatibility for WordPress 2.8+
 * UPDATED Support and Compatibility for WordPress 2.7+
 * UPDATED Support and Compatibility for WordPress 2.6+
 * UPDATED Support and Compatibility for WordPress 2.5+
 * UPDATED Support and Compatibility for WordPress 2.3+
 * UPDATED Support and Compatibility for WordPress 2.2+
 * UPDATED Support and Compatibility for WordPress 2.1+
 * INCLUDED All Features of Major Release 2013.1231.2015
 * INCLUDED All Features of Major Release 2013.1231.2014
 * INCLUDED All Features of Major Release 2013.1231.2013
= To-Do List =
= Branche 2017 (alpha) =
* PHP 7.1+ Compatibility Updates (no date set)
* All in One Virtual and Real Cron Method (no date set)
* Merge Branche 2016 to 2017 (no date set)
= Branche 2016 (alpha) =
* PHP 7.0+ Compatibility Updates (no date set)
* Introducing PHP 5 Construct and Destruct (no date set)
* Merge Branche 2015 to 2016 (no date set)
= Branche 2015 (beta) =
* Admin DashBoard Help and FAQ Panel (2015.1231.2017.6)
* Customization of all Plugin Options (2015.1231.2017.6)
* Admin Menu Classic Plugin Settings Page (2015.1231.2017.6)
= Beta Release =
Beta Version 2015.1231.4.0 Release 2015 Improved FREE:

* Limited Missed Scheduled Posts Fixing per days!
* Preemptive Support PHP 5.5+ and 5.6+ (2015.1231.4.0)
* Network Multisite Improvements (2015.1231.3.0)
* Full Support uninstall.php (2015.0228.3)
* Full Support Uninstall Hook (2015.0228.2)
* Merge Branche 2014 to 2015 (2015.0110.1833)
* New Cron Checking Interval Method (2014.0316.0230)
* Prioritization of Plugin Loading (2014.0316.1111)
= Branche 2014 =
* Preemptive Support PHP 5.5+ and 5.6+ (2014.1231.2016.7)
= Stable Release =
Stable Version 2014.1231.2017.5 Release 2014 FREE:

* Limited Missed Scheduled Posts Fixing per days!
* Preemptive Support WordPress 4.8-RC1 (2014.1231.2017.4)
* Preemptive Support WordPress 4.8-beta (2014.1231.2016.7)
* Preemptive Support WordPress 4.8-alpha (2014.1231.2016.6)
* Preemptive Support WordPress 4.7-beta (2014.1231.2016.5)
* Preemptive Support WordPress 4.7-alpha (2014.1231.2016.4)
* Important Maintenance Support Release (2014.1231.2016.3)
* Undeveloped on wordpress.org to GitHub (2014.1231.2016.2)
* Preemptive Support WordPress 4.6-alpha (2014.1231.2016.1)
* Full Support for WordPress 4.5.0+ Release (2014.1231.2016.1)
* Network Multisite Improvements (2014.1231.2016.1)
* Secunia Zero Advisories Vulnerabilities (2014.1231.2016.0)
* Fixed Panel Loop and Dashboard Freeze (2014.1231.2015.4)
* Preemptive Support WordPress 4.5-alpha (2014.1231.2015)
* Plugin Self Deactivation Festures (2014.1231.2015)
* Full Support for WordPress 4.4.0+ Release (2014.1231.2015)
* Full Support for WordPress 4.3+ Release (2014.1231.2015)
* Full Support for WordPress 4.2+ Release (2014.1231.2015)
* Multisite Uninstall Routine Support (2014.1231.2014)
* Full Support uninstall.php (2014.1231.2014)
* Full Support Uninstall Hook (2014.1231.2014)
* load_plugin_textdomain Loading by Default (2014.1231.2014)
* Preemptive Support WordPress 4.2-alpha (2014.1231.2014)
* Full Support for WordPress 4.1+ Release (2014.1231.2014)
* Full Support for WordPress 4.0+ Release (2014.1231.2014)
* Full Support for WordPress 3.9+ Release (2014.1231.2014)
* Support for all Released WordPress Versions (2014.1231.1)
* Secure Key Tag Auth (a New Idea of sLa)(2014.1231.1)
* Prioritization of Plugin Loading (2014.1231.1)
* Full uninstall db Options Clean Support (2014.1231.1)
* Reduce Server Load with Transients Caching (2014.1231.0)
* Translation Languages Support (basic) (2014.1231.0)
* Dynamic Row Meta link Activation Support (2014.1231.0)
* Check WordPress Version Before Activation (2014.1231.0)
* Plugin Functions Isolation Constructor (2014.1231.0)
* Merge Branche 2013 to 2014 (2014.1231.0)
* Merge Genuine Aut Tag from Pro Version (2014.0221.2015)
* Merge Secured Key Tag from Pro Version (2014.0207.2015)
= Gold Release =
Gold Version 2014.1231.2017.5 Release 2014 FREE:
`
Please noted that the All in One Special Gold Edition
Version with vary Frequencies of Checking is dedicated to
advanced users and was installed only on manual mode!
`
= Development Release =
Development Version (code in becoming) Dev Preemptive FREE:

* Limited Missed Scheduled Posts Fixing per days!
* Customization of all Plugin Options (concept only)
* All in One Virtual and Real Cron Method (concept only)
* Preemptive Support WP 4.9-RC1   (Build 2017.10)
* Preemptive Support WP 4.9-beta4 (Build 2017.9)
* Preemptive Support WP 4.9-beta3 (Build 2017.8)
* Preemptive Support WP 4.9-beta2 (Build 2017.7)
* Preemptive Support WP 4.9-beta1 (Build 2017.6)
* Preemptive Support WP 4.9-alpha (Build 2017.5)
* Preemptive Support WP 4.8-alpha (Build 2017)
* Preemptive Support WP 4.7-alpha (Build 2016)
* Preemptive Support WP 4.6-alpha (Build 2016)
* Preemptive Support WP 4.5-alpha (2015.1221.0450-DEV)
* Preemptive Support WP 4.4-alpha (2015.0818.0440-DEV)
* Preemptive Support WP 4.3-alpha (2015.0323.0430-DEV)
* Preemptive Support WP 4.2-alpha (2014.0912.0420-DEV)
* Translation Languages Support (basic) (2014.0110.1913-DEV)
* Plugin Functions Isolation Constructor (2014.0110.1913-DEV)
* Preemptive Support WP 4.1-alpha (2014.0110.1913-DEV)
* Preemptive Support WP 4.0-alpha (2013.1228.1833-DEV)
* Customization of all Plugin Options (2013.1009.1916-DEV)
* Prioritization Plugin Loading (2013.0824.0312-DEV)
* Preemptive Support WP 3.9-alpha (2013.0730.1530-DEV)
* Unlimited Missed Scheduled Posts Fixing per days! (pro)
* Check Secure Key Tag Auth Before Activation (pro)
* Enable or Disable FrontEnd Header and Footer Log (pro)
* Manual Change the Frequency of Checking (pro)
* Manual Change the Number of Failed Posts Fixed (pro)
* Switching from Local GMT and UTC Time (pro)
= Branche 2013 =
Stable Version 2013.1231.2015 Release 2013 Reloaded FREE:

* Limited Missed Scheduled Posts Fixing per days!
* Fix Activation on localhost or Virtual VPS (2013.1231.2015)
* Full Support for WordPress 4.2+ Release (2013.1231.2015)
* Support for [Theme Check](https://wordpress.org/plugins/theme-check/) Specifications (2013.1231.2014)
* Preemptive Support WordPress 4.2-alpha (2013.1231.2014)
* Full Support for WordPress 4.1+ Release (2013.1231.2014)
* Full Support for WordPress 4.0+ Release (2013.1231.2014)
* Full Support for WordPress 3.9+ Release (2013.1231.2014)
* Preemptive Support WordPress 3.9-alpha (2013.1231.2013)
* Full Support for WordPress 3.8+ Release (2013.1231.2013)
* Full Support for WordPress 3.7+ Release (2013.1231.2013)
* Full Support for WordPress 3.6+ Release (2013.1231.2013)
* Preemptive Support WordPress 3.8-alpha (2013.1212.9999)
* Preemptive Support WordPress 3.7-alpha (2013.1024.8888)
* Ticket #4218662 [HyperDB Compatibility](https://wordpress.org/support/topic/resolving-table_name-from-query-broken-in-select-query) (2013.0730.7777)
* Checking 10 Future Posts for 5 Minute (2013.0726.6666)  
* Queries and CPU Speedup (2013.0725.5555) Jack Hayhurst
* AllinOne Pack with Vary Check Frequency (2013.0531.4444)
* Key Tag Plugin Authenticity (2013.0131.3333)
* Ticket #4163854 [W3 Total Cache Conflict](https://wordpress.org/support/topic/any-conflicts-with-w3-cache/) (2013.0131.3333)
* Compatibility of Third Party Caching Plugins (2013.0131.3333)
* Ticket #3712701 [TimeZone Issues](https://wordpress.org/support/topic/publishing-ahead-of-schedule-timezone-issues/) (2013.0131.3333)
* Default WordPress Items Feed Syndication Support (2013.0131.3333)
* Transparency of JetPack and others Publishing Plugins (2013.0131.3333)
* Free Interference with others Scheduled Cron Jobs (2013.0131.3333)
* Preemptive Support WordPress 3.6-alpha (2013.0131.3333)
* Ticket #3786523 [Strange Messages](https://wordpress.org/support/topic/activate-the-plugin-then-show-strange-messages/) (2013.0130.2222)
* Scheduled Posts Regression <a href="https://core.trac.wordpress.org/ticket/22944">#22944</a> (2013.0106.1111)
* Full Support for WordPress 3.5.0+ Release (2013.0106.1111)
= 2013.1231.2015 =
* Major Release [RELOADED] The plugin does not have a valid header!
 * Please update as soon as possible!
 * Branche 2013 Build 2015-12-31
 * Release 2013 Revision 2015 Update 0
 * Full Support and Compatibility for WordPress 2.3+ - 4.4.0+
 * Preemptive Support for WordPress 4.5-alpha
 * MAINTENANCE Release According WordPress 4.4.0+
 * MAINTENANCE Release According WordPress 4.3+
 * MAINTENANCE Release According WordPress 4.2+
 * MERGED Genuine Aut Tag from Pro Version (Only for Admin)
 * MERGED Secured Key Tag from Pro Version (Only for Admin)
 * FIXED Error [The plugin does not have a valid header](https://wordpress.org/support/topic/the-plugin-does-not-have-a-valid-header-72)
 * FIXED Activation on localhost (127.0.0.1) Installations.
 * FIXED Activation on local XAMPP, EASYPHP, Installations.
 * FIXED Activation on Virtual VPS WordPress Installations.
 * FIXED Activation on others type of Virtual installations.
 * NEW Renamed Distribution Files on Special Gold Edition.
 * NEW Action Link Cron accessible with [WP Crontrol](https://wordpress.org/plugins/wp-crontrol/) Active.
 * NEW Fully Compatible with WordPress Multisite Install.
 * THANKS to [Jan Dembowski](https://wordpress.org/support/profile/jdembowski) for help me to discover this issue.
 * INCLUDED All Features of Major Release 2013.1231.2014
 * BUMP Version 2013 Build 1231 Revision 2015 Update 0
 *
 * PREVIOUS 2013.1231.2014 RELEASE HISTORY
 *
 * Major Release [RELOADED] Both DOS and UNIX EOL SVN error!
 * Branche 2013 Build 2014-12-31
 * Release 2013 Revision 2014 Update 0
 * Full Support and Compatibility for WordPress 2.3+ - 4.1+
 * Preemptive Support for WordPress 4.2-alpha
 * MAINTENANCE Release According WordPress 4.1+
 * MAINTENANCE Release According WordPress 4.0+
 * MAINTENANCE Release According WordPress 3.9+
 * FIXED Both DOS and UNIX EOL causes SVN repo problems.
 * FIXED You have not included a Text Domain Problems.
 * UPDATED [Special Gold Edition](https://wordpress.org/support/topic/special-gold-edition-version-installation-guide) installation guide.
 * INCLUDED All Features of Major Release 2013.1231.2013
 *
 * PREVIOUS 2013.1231.2013 RELEASE HISTORY
 *
 * Major Release [RELOADED] One year of testing and bug corrections!
 * Branche 2013 Build 2013-12-31
 * Release 2013 Revision 2013 Update 0
 * Full Support and Compatibility for WordPress 2.3+ - 3.8+
 * Preemptive Support for WordPress 3.9-alpha
 * MAINTENANCE Release According WordPress 3.8+
 * MAINTENANCE Release According WordPress 3.7+
 * MAINTENANCE Release According WordPress 3.6+
 * FIXED infrequent freeze when deactivate or delete it.
 * FIXED issue discuss [here](https://wordpress.org/support/topic/bug-published-future-posts-after-update).
 * FIXED ticket #4163854 [W3 Total Cache Conflict](https://wordpress.org/support/topic/any-conflicts-with-w3-cache/).
 * FIXED ticket #3786523 [Strange Messages](https://wordpress.org/support/topic/activate-the-plugin-then-show-strange-messages/) in some rare hosting configurations.
 * FIXED ticket #3712701 [TimeZone Issues](https://wordpress.org/support/topic/publishing-ahead-of-schedule-timezone-issues/).
 * FIXED non-ascii characters readme.txt issues thanks to Samuel Wood (Otto).
 * FIXED [LIMIT]
 * FIXED low resource hosting slowness when execute session task.
 * FIXED some hosting crash with full strict security rules (.htaccess)
 * FIXED WordPress [wp_schedule_single_event](https://codex.wordpress.org/function_reference/wp_schedule_single_event) function behavior.
 * FIXED WordPress [wp_publish_post](https://codex.wordpress.org/function_reference/wp_publish_post) function behavior.
 * FIXED execution time.
 * NEW key tag plugin authenticity.
 * NEW header and footer log.
 * NEW functions isolation constructor.
 * NEW default WordPress items (10 each session) feed syndication support.
 * NEW fast queries and cpu load (5 minutes) optimization by Jack Hayhurst.
 * NEW [HyperDB Query Compatibility](https://wordpress.org/support/topic/resolving-table_name-from-query-broken-in-select-query).
 * NEW [Special Gold Edition](https://wordpress.org/support/topic/special-gold-edition-version-installation-guide) all in one files versions with vary frequency of check.
 * UPDATED key tag plugin mechanism.
 * UPDATED header and footer log descriptions.
 * UPDATED scheduled failed future posts recovery and fixing.
 * UPDATED more accurate link on plugin control panel description.
 * UPDATED [LIMIT]
 * UPDATED realtime checking: 1 session every 5 minutes.
 * UPDATED realtime checking: 10 future posts every 5 minute.
 * UPDATED realtime checking: 12 sessions every hour.
 * UPDATED realtime checking: 120 items every hour.
 * UPDATED license.txt distribution license copy.
 * UPDATED index.html directory listing protection.
 * UPDATED index.php directory listing protection.
 * UPDATED .htaccess strict security rules.
 * REMOVED [WPMS_DELAY]
 * REMOVED plugin advertising thanks to Ipstenu (Mika Epstein).
 * REMOVED all non-ascii plugin header characters thanks to Samuel Wood (Otto).
 * REPLACED replaced wp_future_post function with wpms_future_post
 * SECURITY a new idea of sla: key tag plugin authenticity.
 * SECURITY checksum.txt md5 checksum declaration.
 * SECURITY prevent direct access to php files on this plugin.
 * SECURITY keybit.txt plugin authenticity protection.
 * SECURITY index.html directory listing protection.
 * SECURITY index.php directory listing protection.
 * SECURITY .htaccess strict security rules.
 * SECURITY nothing is written into hosting space disk.
 * ENHANCEMENT check minimun WordPress version required for plugin activation.
 * ENHANCEMENT default WordPress items feed syndication support.
 * ENHANCEMENT maximized stability and speedup performances.
 * ENHANCEMENT compatibility of third party caching plugins.
 * ENHANCEMENT transparency of jetpack and others publishing plugins.
 * ENHANCEMENT free interference with others scheduled cron jobs at scale.
 * ENHANCEMENT code cleanup for faster loading.
 * ENHANCEMENT reduce code bloat.
 * ENHANCEMENT redefinied functions for best timeline.
 * ENHANCEMENT delete registered database options hooks on plugin deactivation.
 * ENHANCEMENT ready to single and network multisite environment.
 * ENHANCEMENT plugin memory consumption (less of 1kb or no more).
 * ENHANCEMENT full strict security rules applied.
 * ENHANCEMENT work with shared and vps hosting.
 * INTRODUCED concept of pro version for future development and survivor.
 *
 * Old Release History, before 2013, is available on [changelog.txt](http://plugins.svn.wordpress.org/wp-missed-schedule/assets/changelog.txt)
 *
== Upgrade Notice ==
= 2014.1231.2017.12 =
Major Release and Compatibility Maintenance Update for WordPress from 2.1+ to 4.9+ and 5.0-alpha (recommended PHP 5.4+) Build 2017-12-31 - Somes Important Core Optimizations and Transients Improvements - Undeveloped on wordpress.org since 2016-04-13 - Available only on GitHub for Specific Author Request - Upgradable directly from WordPress Dashboard on GitHub only - Secunia Certified Zero Vulnerabilities Advisories!
== Disclaimer ==
[sLaNGjIs Team not provide support on wordpress.org forum](https://slangji.wordpress.com/support/) because we are not interested in reviews o stars on our plugins and themes!

Dear user of plugins or themes: Missed Schedule is a WordPress Bug!

sLaNGjIs Team has started official adventure on WordPress.org forum since 2007!

Everything was very different from today: the plugins and themes developed by us were much less, and also the users who used it.

The traffic generated by users of the WordPress.org forum has increased exponentially, and in the same way also the requests for assistance have increased exponentially.

In the near future this increase will be even more pronounced, as a result of the great success of WordPress.

By contrast, both the posts and threads definable requests and those definable trash are very difficult to finding and follow: the time necessary for this purpose, now, longer a nightmare that one added value service, real.

The problems of this type of assistance, through that instruments, have been deemed ineffective by more and more developers excellent, while the tools available for this workload considered inadequate to many of them.

Many of these developers have already abandoned this platform of assistance by providing others methods of support.

Our team has tried to respond to all for more long years, and maintained the support forums for plugins and themes developed always clean.

Due to this big limitation of platform, and the result of failing to provide a service that gives us satisfaction, as of today August 15 2014, we abandon the active support of this type of structure, started since July 7 2007, to try to give one type of personalized service, targeted to the requests of real user utilization and totally Free of Charge:

1. Bugs [sLaNGjI's GitHub](https://github.com/sLaNGjI/)
1. Suggestions [sLaNGjI's Contact](http://slangjis.org/contact/)
1. Support [sLaNGjI's Premium](https://slangji.wordpress.com/support/premium/)

* Please note that:
 * We are not interested in reviews.
 * Do not write anything like that!
 * We are not interested in stars.
 * Do not make any in that sections!

Possibility that some of us then reply or write on it, will be very low!
== Philosophy ==
The sLaNGjIs Team Philosophy.

**sLaNGjIs Team plugins and themes are NoLogo**

The philosophy of sLaNGjIs Team plugins and themes is:

*LICENSING*

* GPLv3 or later   - officially allowed - update licensing asap
* GPLv2 or later   - deprecated - not retroactive - update licensing asap to GPLv3
* GPLv3 or greater - deprecated - not applicable  - because greater corresponds to GPLv4
* GPLv2 or greater - deprecated - not applicable  - update licensing asap to GPLv3

*BRANDING*

* NO LOGO - all works and programs include nologo philosophy.
* This is because the name of the icons for the plugins and themes is
  icon128x128.png or icon256x256.png and NOT logo128x128.png or logo256x256.png

*TRANSLATION*

* GlotPress is NOT trusted and supported for now on plugins and themes of this team.
* All GlotPress files .pot and .mo automatically distributed is NOT trusted for now.
* All GlotPress description is possible that differ from original of it author.
* All GlotPress translated link is possible that differ from original of it author.
* The use of both it's at your own risk.
* No translations is supported officially except only for single verified words.

*INDENTATION*

* Only GNU indentations is supported, no others.
* No minified code is distributed: never.

*DISTRIBUTION*

* Only official plugins and themes distribution on WordPress.org repositpory is safe.
* Please verify if the integrity of your distribution files SHA1 CHECKSUM is original.
* Only original online copy of checksum.txt SHA1 on WordPress.org repository is safe.
* Please verify if the KeyTag and AuthTag included on all main files is original.
* Only original online copy of KeyTag and AuthTag on WordPress.org repository is safe.
* If all steps is not executed was declined any implicit and explicit responsabulity.
* If all steps is not executed was declined any implicit and explicit damages.
* All this checks was a necessary security rules beacause is possible modify and
  redistribute malformed and malicious distribution files .zip

*DONATION*

* All plugins and themes is free: no money was given for it.
* This is true on all internet places, included all that is not official.

*SUPPORT*

* No support is provided on WordPress.org forum and reviews.
* No reviews please: this team not need any of it.
* No stars please: this team not need any of it.
* But, please, not add fake stars, reviews and requests.

*PREMIUM*

* All premium support is free of charges.
* Never is requested moneys for it, on any situation, except for no bug fix requests.
* But, for the nature of this, not all requests are processed, except only for all
  that it is was considered legitimate.

*PRO AND GOLD*

* The versions of the plugins and themes are not the same of the repository.
* All of this correspond to another method of distribution, and another situation.

Thanks!