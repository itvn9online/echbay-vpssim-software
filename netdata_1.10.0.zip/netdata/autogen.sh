#!/usr/bin/env sh
autoreconf -ivf
