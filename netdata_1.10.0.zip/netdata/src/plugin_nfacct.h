#ifndef NETDATA_NFACCT_H
#define NETDATA_NFACCT_H 1

extern void *nfacct_main(void *ptr);

#endif /* NETDATA_NFACCT_H */

