#ifndef NETDATA_PLUGIN_PROC_DISKSPACE_H
#define NETDATA_PLUGIN_PROC_DISKSPACE_H

extern void *proc_diskspace_main(void *ptr);

#endif //NETDATA_PLUGIN_PROC_DISKSPACE_H
