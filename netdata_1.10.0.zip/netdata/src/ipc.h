#ifndef NETDATA_PLUGIN_IPC_H
#define NETDATA_PLUGIN_IPC_H 1

extern int do_ipc(int update_every, usec_t dt);

#endif /* NETDATA_PLUGIN_IPC_H */

